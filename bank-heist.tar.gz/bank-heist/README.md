# Bank Heist Challenge

Our sources have intercepted the source code for ZeroTrust Bank's high-speed lending protocol.


## Structure
*   `program/`: The bank smart contract.
*   `server/`: The challenge server that interacts with the user.
*   `framework/`: Testing framework used by the server.

## How to Run Locally

You can run the challenge locally using Docker. This ensures you have the exact same environment as the remote server.

### Prerequisites
*   Docker
*   Docker Compose

### Steps
1.  Navigate to the `bank-heist` directory:
    ```bash
    cd bank-heist
    ```
2.  Start the challenge container:
    ```bash
    docker-compose up --build
    ```
3.  Connect to the server:
    The server will be listening on port `5000`. You can connect to it using `nc` (netcat) or a script.
    ```bash
    nc localhost 5000
    ```


## Acknowledgements
This challenge uses the [sol-ctf-framework](https://github.com/otter-sec/sol-ctf-framework) by otter-sec.
