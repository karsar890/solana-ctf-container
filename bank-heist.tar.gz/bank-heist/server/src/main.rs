use sol_ctf_framework::ChallengeBuilder;

use solana_sdk::{
    pubkey::Pubkey,
    account::Account,
    signature::{Keypair, Signer},
};
use solana_system_interface::program as system_program;

use std::{
    fs,
    io::Write,
    error::Error,
    net::{
        TcpListener,
        TcpStream
    },
};

use bank_heist::get_bank_pda;

#[tokio::main]
async fn main() -> Result<(), Box<dyn Error>> {
    let listener = TcpListener::bind("0.0.0.0:5000")?;
    println!("Server listening on port 5000...");
    loop {
        let (stream, _) = listener.accept()?;
        tokio::spawn(async move {
            if let Err(e) = handle_connection(stream).await {
                eprintln!("handler error: {e}");
            }
        });
    }
}

async fn handle_connection(mut socket: TcpStream) -> Result<(), Box<dyn Error>> {
    let mut builder = ChallengeBuilder::try_from(socket.try_clone().unwrap()).unwrap();

    let solve_pubkey = match builder.input_program() {
        Ok(pubkey) => pubkey,
        Err(e) => {
            writeln!(socket, "Error: cannot add solve program -> {e}")?;
            return Ok(());
        }
    };

    let program_key = Pubkey::new_unique();
    let program_pubkey = builder.add_program(&"./bank_heist.so", Some(program_key)).expect("Duplicate pubkey supplied");

    let user = Keypair::new();

    writeln!(socket, "program: {}", program_pubkey)?;
    writeln!(socket, "user: {}", user.pubkey())?;

    let (bank_vault, _) = get_bank_pda(&program_pubkey);

    const BANK_INITIAL_BALANCE: u64 = 1_000_000_000;
    const USER_INITIAL_BALANCE: u64 =     1_000_000; 

    builder
        .builder
        .add_account(user.pubkey(), Account::new(USER_INITIAL_BALANCE, 0, &system_program::ID));
    
    builder
        .builder
        .add_account(bank_vault, Account::new(BANK_INITIAL_BALANCE, 0, &system_program::ID));

    let mut challenge = builder.build().await;
    
    writeln!(socket, "Send First Instruction:")?;
    let ix1 = challenge.read_instruction(solve_pubkey)?;
    
    writeln!(socket, "Send Second Instruction:")?;
    let ix2 = challenge.read_instruction(solve_pubkey)?;

    challenge.run_ixs_full(
        &[ix1, ix2],
        &[&user],
        &user.pubkey(),
    ).await?;

    let bank_balance = challenge.ctx.banks_client.get_account(bank_vault).await?.map(|a| a.lamports).unwrap_or(0);
    
    writeln!(socket, "Bank Vault Balance: {}", bank_balance)?;

    if bank_balance < 1_000_000 {
        let flag = fs::read_to_string("flag.txt").unwrap_or_else(|_| "flag{test_flag}".to_string());
        writeln!(socket, "Congratulations! You robbed the bank!\nFlag: {}", flag)?;
    } else {
         writeln!(socket, "The bank is still solvent. Try harder!")?;
    }

    Ok(())
}
