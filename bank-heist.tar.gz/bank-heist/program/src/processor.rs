use borsh::{BorshDeserialize, BorshSerialize};
use solana_program::{
    account_info::{next_account_info, AccountInfo},
    entrypoint::ProgramResult,
    msg,
    program::{invoke, invoke_signed},
    program_error::ProgramError,
    pubkey::Pubkey,
    sysvar::{instructions, slot_hashes, Sysvar},
    rent::Rent,
};

use solana_system_interface::instruction as system_instruction;

use crate::{get_bank_pda, get_user_pda, BankInstruction, UserAccount};

pub fn process_instruction(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    data: &[u8],
) -> ProgramResult {
    let instruction = BankInstruction::deserialize(&mut &data[..])?;

    match instruction {
        BankInstruction::OpenAccount => {
            msg!("Instruction: Open Account");
            process_open_account(program_id, accounts)
        }
        BankInstruction::VerifyKYC { proof } => {
            msg!("Instruction: Verify KYC");
            process_verify_kyc(program_id, accounts, proof)
        }
        BankInstruction::RequestLoan { amount } => {
            msg!("Instruction: Request Business Loan");
            process_request_loan(program_id, accounts, amount)
        }
    }
}

fn process_open_account(program_id: &Pubkey, accounts: &[AccountInfo]) -> ProgramResult {
    let account_info_iter = &mut accounts.iter();
    let user = next_account_info(account_info_iter)?;
    let user_pda = next_account_info(account_info_iter)?;
    let system_program = next_account_info(account_info_iter)?;

    if !user.is_signer {
        return Err(ProgramError::MissingRequiredSignature);
    }

    let (pda, bump) = get_user_pda(user.key, program_id);
    if pda != *user_pda.key {
        return Err(ProgramError::InvalidAccountData);
    }

    if !user_pda.data_is_empty() {
        return Err(ProgramError::AccountAlreadyInitialized);
    }

    let rent = Rent::get()?;
    let space = 1; 
    let lamports = rent.minimum_balance(space);

    invoke_signed(
        &system_instruction::create_account(
            user.key,
            user_pda.key,
            lamports,
            space as u64,
            program_id,
        ),
        &[user.clone(), user_pda.clone(), system_program.clone()],
        &[&[b"user", user.key.as_ref(), &[bump]]],
    )?;

    let mut user_account = UserAccount { kyc_verified: false };
    user_account.serialize(&mut &mut user_pda.data.borrow_mut()[..])?;

    Ok(())
}

fn process_verify_kyc(program_id: &Pubkey, accounts: &[AccountInfo], proof: u64) -> ProgramResult {
    let account_info_iter = &mut accounts.iter();
    let user_pda = next_account_info(account_info_iter)?;
    let slot_hashes_sysvar = next_account_info(account_info_iter)?;
    let user = next_account_info(account_info_iter)?;
    
    let (pda, _bump) = get_user_pda(user.key, program_id);
    if pda != *user_pda.key {
        return Err(ProgramError::InvalidAccountData);
    }

    if *slot_hashes_sysvar.key != slot_hashes::id() {
        return Err(ProgramError::InvalidArgument);
    }
    
    let slot_hashes: slot_hashes::SlotHashes = bincode::deserialize(&slot_hashes_sysvar.data.borrow())
        .map_err(|_| ProgramError::InvalidAccountData)?;
    
    if slot_hashes.is_empty() {
        return Err(ProgramError::InvalidAccountData);
    }
    
    let recent_hash = slot_hashes[0].1; 
    let bytes = recent_hash.as_ref(); 
    
    let mut part1_bytes = [0u8; 8];
    part1_bytes.copy_from_slice(&bytes[0..8]);
    let part1 = u64::from_le_bytes(part1_bytes);

    let mut part2_bytes = [0u8; 8];
    part2_bytes.copy_from_slice(&bytes[8..16]);
    let part2 = u64::from_le_bytes(part2_bytes);

    let expected = part1.rotate_left(12) ^ part2.wrapping_add(0xFEEDC0DE);
    
    if proof != expected {
        return Err(ProgramError::InvalidArgument);
    }
    
    let mut user_account = UserAccount::deserialize(&mut &user_pda.data.borrow()[..])?;
    user_account.kyc_verified = true;
    user_account.serialize(&mut &mut user_pda.data.borrow_mut()[..])?;

    Ok(())
}

fn process_request_loan(program_id: &Pubkey, accounts: &[AccountInfo], amount: u64) -> ProgramResult {
    let account_info_iter = &mut accounts.iter();
    let bank_pda = next_account_info(account_info_iter)?;
    let user = next_account_info(account_info_iter)?;
    let instructions_sysvar = next_account_info(account_info_iter)?;
    let user_account_pda = next_account_info(account_info_iter)?; 
    let system_program = next_account_info(account_info_iter)?;

    if user_account_pda.owner != program_id {
         return Err(ProgramError::IllegalOwner);
    }
    
    let (derived, _bump) = get_user_pda(user.key, program_id);
    if derived != *user_account_pda.key {
         return Err(ProgramError::InvalidAccountData);
    }

    let user_state = UserAccount::deserialize(&mut &user_account_pda.data.borrow()[..])?;
    if !user_state.kyc_verified {
        return Err(ProgramError::Custom(403));
    }

    let (pda, bump) = get_bank_pda(program_id);
    if pda != *bank_pda.key {
        return Err(ProgramError::InvalidAccountData);
    }

    invoke_signed(
        &system_instruction::transfer(bank_pda.key, user.key, amount),
        &[bank_pda.clone(), user.clone(), system_program.clone()],
        &[&[b"BANK", &[bump]]],
    )?;

    verify_repayment(instructions_sysvar, bank_pda.key, amount)?;

    Ok(())
}

fn verify_repayment(
    instructions_sysvar: &AccountInfo,
    bank_pda: &Pubkey,
    expected_amount: u64,
) -> ProgramResult {
    let current_index = instructions::load_current_index_checked(instructions_sysvar)?;
    
    
    
    if let Ok(next_ix) = instructions::load_instruction_at_checked(
        (current_index as usize) + 1,
        instructions_sysvar
    ) {
        
        if next_ix.data.len() < 12 {
            msg!("Invalid repayment instruction data len");
            return Err(ProgramError::InvalidInstructionData);
        }
        
        let discriminant = u32::from_le_bytes(next_ix.data[0..4].try_into().unwrap());
        let amount = u64::from_le_bytes(next_ix.data[4..12].try_into().unwrap());
        
        if discriminant != 2 { 
             msg!("Next instruction is not a transfer");
             return Err(ProgramError::InvalidInstructionData);
        }
        
        if amount < expected_amount {
             msg!("Repayment amount insufficient");
             return Err(ProgramError::InsufficientFunds);
        }
        
        if next_ix.accounts.len() < 2 {
             msg!("Not enough accounts in repayment");
             return Err(ProgramError::InvalidAccountData);
        }
        
        let destination_meta = &next_ix.accounts[1];
        if destination_meta.pubkey != *bank_pda {
             msg!("Repayment destination is not bank vault");
             return Err(ProgramError::InvalidAccountData);
        }
        
        
        msg!("Repayment verified: will return {}", amount);
        Ok(())
    } else {
        msg!("No repayment instruction found after flash loan");
        Err(ProgramError::InvalidInstructionData)
    }
}
