mod entrypoint;
pub mod processor;

use borsh::{BorshDeserialize, BorshSerialize};
use solana_program::{
    instruction::Instruction,
    pubkey::Pubkey,
};

#[derive(BorshDeserialize, BorshSerialize, Debug, Clone, PartialEq)]
pub enum BankInstruction {
    OpenAccount,

    VerifyKYC {
        proof: u64,
    },

    RequestLoan {
        amount: u64,
    },
}

#[derive(BorshDeserialize, BorshSerialize, Debug)]
pub struct BankState {
    pub total_deposits: u64,
}

#[derive(BorshDeserialize, BorshSerialize, Debug, Clone, Copy, PartialEq)]
#[repr(C)]
pub struct UserAccount {
    pub kyc_verified: bool,
}

pub fn get_bank_pda(program_id: &Pubkey) -> (Pubkey, u8) {
    Pubkey::find_program_address(&[b"BANK"], program_id)
}

pub fn get_user_pda(user: &Pubkey, program_id: &Pubkey) -> (Pubkey, u8) {
    Pubkey::find_program_address(&[b"user", user.as_ref()], program_id)
}
